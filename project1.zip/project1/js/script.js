/*============================ typing animation=======================*/
var typed = new Typed(".typing",{
    strings:["Student","web Designer", "Web Devloper","Editor"],
    typeSpeed:100,
    BackSpeed:60,
    loop:true
})
/*===========typing  aside===========*/
const nav= document.querySelector(".nav"),
navlist=nav.querySelectorAll("li"),
totalNavList = navlist.length;
for(let i= 0; i<totalNavList; i++)

{
console.log(navlist[i])
const a=navlist[i]
}